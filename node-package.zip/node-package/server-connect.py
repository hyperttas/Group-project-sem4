import asyncio
import ssl
import json
import base64
import uuid
import importlib.util
import sys
from pathlib import Path

HOST = "192.168.189.8"
PORT = 4433

pending = {}

current_job_id = 0

job_output = {}

def load_tmp_script():
    script_path = Path("tmp_script.py")
    module_name = "tmp_script"

    # Remove the module from sys.modules if it's already loaded
    if module_name in sys.modules:
        del sys.modules[module_name]

    # Load the module from the file path
    spec = importlib.util.spec_from_file_location(module_name, script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    return module


async def send_message(writer, message):
    req_id = str(uuid.uuid4())
    message["id"] = req_id

    loop = asyncio.get_running_loop()
    future= loop.create_future()
    pending[req_id] = future

    writer.write((json.dumps(message) + "\n").encode())
    await writer.drain()

    return await future

async def read_responses(reader):
    while True:
        raw = await reader.readline()
        if not raw:
            break
        msg = json.loads(raw.decode())
        print("Received:", msg)
        req_id = msg.get("id")

        if req_id in pending:
            pending.pop(req_id).set_result(msg)

async def connect_to_controller(writer):
    #One-time handshake
    writer.write((json.dumps({"action": "ack"}) + "\n").encode())
    await writer.drain()

async def scan_job_local():
    with open('tmp_script.py', 'r') as f:
        if len(f.read()) > 0:
            print("Found an existing job on this node, calculating...")
            await solve_job()

async def ping_task(writer):
    global current_job_id
    while True:
        if current_job_id != 0:
            await asyncio.sleep(5)
            continue
        response = await send_message(writer, {"action": "ping"})
        if 'task' in response:
            if response['job_id'] != current_job_id:
                task = base64.b64decode(response['task']).decode("utf-8")
                script = base64.b64decode(response['script']).decode("utf-8")
                current_job_id = response['job_id']
                print("This job's ID:", current_job_id)
                #save json temporarily to their files
                with open ("tmp_task.json", "w", encoding="utf-8") as f:
                    f.write(task)
                with open ("tmp_script.py", "w", encoding="utf-8") as f:
                    f.write(script)
                print("Saved task and script")
                await solve_job()
        await asyncio.sleep(5)

async def solve_job():
    global job_output
    print("\nInitiating job... please stand by.")
    tmp_script_module = await asyncio.to_thread(load_tmp_script)
    job_output= await asyncio.to_thread(tmp_script_module.solve_job)
    print("\nJob successfully solved!")
    print("Job output", job_output)

async def send_result(writer):
    while True:
        global current_job_id
        global job_output
        if len(job_output) > 0:
            print("\nJOB OUTPUT FOUND, CONTACTING CONTROLLER")
            response = await send_message(writer, {'action': 'job_complete'})
            if "ok" in response['status']:
                print('Sending job result to controller...')
                response = await send_message(writer, {'action':'job_payload', 'data':[current_job_id,job_output]})
                if "ok" in response['status']:
                    print("\nDELETING TMP FILE CONTENTS")
                    open('tmp_script.py', 'w').close()
                    open('tmp_task.json', 'w').close()
                    current_job_id = 0
                    job_output = {}
                    await asyncio.sleep(5)
                else:
                    print("An error has occurred, the controller has not received the data. Trying again later...")
                    await asyncio.sleep(5)
            else:
                print("Error: Controller has not responded with an 'ok' signal")
                await asyncio.sleep(5)
        else:
            await asyncio.sleep(10)

async def main():
    context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    context.load_cert_chain("certs/node/node.crt", "certs/node/node.key")
    context.load_verify_locations("certs/ca/ca.crt")

    reader, writer = await asyncio.open_connection(
        HOST,
        PORT,
        ssl=context
    )

    asyncio.create_task(read_responses(reader))
    await scan_job_local()
    await connect_to_controller(writer)
    await asyncio.gather(
        ping_task(writer),
        send_result(writer),
    )

if __name__ == "__main__":
    asyncio.run(main())
